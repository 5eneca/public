#include <iostream>
#include <string>
#include <vector>
using namespace std;

bool checkSentence(const string& str)
{        
    if (!isupper(str[0]))
        return false;    
    
    if (str.back() != '.')
        return false;    
        
    int prev_state = 0, curr_state = 0;    
    for (char ch : str)
    {                
        if (isupper(ch))
            curr_state = 0;        
        else if (ch == ' ')
            curr_state = 1;        
        else if (islower(ch))
            curr_state = 2;        
        else if (ch == '.')
            curr_state = 3;        
        
        if (prev_state == curr_state && curr_state != 2)
            return false;        
        if (prev_state == 2 && curr_state == 0)
            return false;        
        
        prev_state = curr_state;
    }    
    return true;
}

int main()
{
    vector<string> sentences = {
        "I love to code.",
        "I am single.",
        "My name is NAzia.",
        "I lovE cinema.",
        "hi. is a quiz site.",
        "I love cse.",
        " You are my friend.",
        "I love to code"
    };    
    
    for (const auto& sentence : sentences)
    {
        if (checkSentence(sentence))
            cout << "\"" << sentence << "\" is correct." << endl;
        else
            cout << "\"" << sentence << "\" is incorrect." << endl;
    }    
    
    return 0;
}
