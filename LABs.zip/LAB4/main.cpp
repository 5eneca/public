#include <iostream>
#include <fstream>
#include <regex>
#include <string>

using namespace std;

void analyze_variable_declarations(const string& code) {
    regex pattern(R"(\b(?:int|char|float|double|long|short|unsigned|signed)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*(?:=[^;]*)?;)");
    
    auto words_begin = sregex_iterator(code.begin(),
                                       code.end(),
                                       pattern);
    auto words_end = sregex_iterator();

    cout << "Found variable declarations:" << endl;
    for (sregex_iterator i = words_begin; i != words_end; ++i) {
        smatch match = *i;
        cout << match[1] << endl; 
    }
    cout << endl;
}

void analyze_function_declarations(const string& code) {
    regex pattern(R"(\b(?:void|int|char|float|double|long|short|unsigned|signed)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\([^)]*\)\s*(?:const)?\s*;)");
    
    vector<string> function_declarations;
    
    auto words_begin = sregex_iterator(code.begin(), 
                                       code.end(), 
                                       pattern);
    auto words_end = sregex_iterator();

    cout << "Found function declarations:" << endl;
    for (sregex_iterator i = words_begin; i != words_end; ++i) {
        smatch match = *i;
        function_declarations.push_back(match[1]); 
    }
    
    if (code.find("int main(") != string::npos) {
        function_declarations.push_back("main");
    }
    
    for (const auto& func : function_declarations) {
        cout << func << endl;
    }
    cout << endl;
}

void analyze_function_definitions(const string& code) {
    regex pattern(R"(\b(?:void|int|char|float|double|long|short|unsigned|signed)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\([^)]*\)\s*(?:const)?\s*\{[^{}]*\})");
    vector<string> function_definitions;
    auto words_begin = sregex_iterator(code.begin(), 
                                       code.end(), 
                                       pattern);
    auto words_end = sregex_iterator();

    cout << "Found function definitions:" << endl;
    for (sregex_iterator i = words_begin; i != words_end; ++i) {
        smatch match = *i;
        function_definitions.push_back(match[0]); 
    }

    for (const auto& func_def : function_definitions) {
        cout << func_def << endl;
    }
    cout << endl;
}

int main() {
    string filename = "file.txt";

    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file " << filename << endl;
        return 1;
    }

    string source_code((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
    file.close();

    analyze_variable_declarations(source_code);
    analyze_function_declarations(source_code);
    analyze_function_definitions(source_code);

    return 0;
}

