#include <iostream>
#include <string>
using namespace std;

int main() {
  string first_name, last_name, full_name, tmp;
  cout << "Enter first name: ";
  cin >> first_name;
  cout << "Enter last name: ";
  cin >> last_name;

  full_name = first_name + " " + last_name;

  cout << endl;
  // cout << "First Name: " << first_name << endl;
  // cout << "Last Name: " << last_name << endl;
  cout << "Full Name: " << full_name << endl;

  return 0;
}
