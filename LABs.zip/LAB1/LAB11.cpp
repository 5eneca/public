#include <iostream>
using namespace std;

int main() {
  int _arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
  size_t length = (sizeof(_arr)/sizeof(_arr[0]));

  cout << "[";
  for(size_t i = 0; i < length; i++)
    cout << _arr[i] << ((i == length - 1) ? "" : " "); 
  cout << "]" << endl;

  int total = 0;
  for (int x : _arr) total += x;
  cout << "Average: "
       << total / (sizeof(_arr) / (float)sizeof(_arr[0]))
       << endl;
}
