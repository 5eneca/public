#include <fstream>
#include <iostream>
#include <map>

using namespace std;

void InsertMode(map<string, float> &);
void ReadMode(map<string, float> &);
void WriteMode(map<string, float> &);

int main() {
  map<string, float> students;
  string choice;

  while (true) {
    cout << "Current Buffer: ";

    if(students.empty()) cout << "[]" << endl;
    else {
      cout << "[ ";
      for(auto student : students) {
        cout << "\"" << student.first << "\""
             << ": " << student.second
             << ", ";
      }
      cout << "]" << endl;
    }

    cout << "[i] Enter Insert Mode." << endl;
    cout << "[r] Enter Read Mode." << endl;
    cout << "[w] Enter Write Mode." << endl;
    cout << "[Anything Else] Exit." << endl;
    cout << "Enter Choice: ";
    cin >> choice;

    if (choice == "i")
      InsertMode(students);
    else if (choice == "r")
      ReadMode(students);
    else if (choice == "w")
      WriteMode(students);
    else
      break;
  }
  return 0;
}

void InsertMode(map<string, float> &students) {
  int number_of_students;
  string name;
  float marks;

  students.clear();

  cout << "Enter the number of students: ";
  cin >> number_of_students;

  for (size_t i = 0; i < number_of_students; i++) {
    cin.ignore(80, '\n');
    cout << "Enter Student Name: ";
    getline(cin, name);
    cout << "Enter marks: ";
    cin >> marks;

    students.insert({name, marks});
  }
  cout << endl;
}

void ReadMode(map<string, float> &students) {
  string tmp_line;
  ifstream file("students.txt");
  
  cout << endl;
  while (getline(file, tmp_line))
    cout << tmp_line << endl;
  file.close();
  cout << endl;
}

void WriteMode(map<string, float> &students) {
  ofstream file("students.txt", ios_base::app);

  for (auto const &[_name, _marks] : students)
    file << _name << ", " << _marks << endl;
  file.close();

  cout << endl << "Success!" << endl << endl;
}
