#include <iostream>
#include <string>
using namespace std;

bool isOperator(const char& c) {
    return  c == '!' ||
            c == '%' ||
            c == '<' ||
            c == '>' ||
            c == '+' ||
            c == '-' ||
            c == '*' ||
            c == '/' ||
            c == '=';
}

int main() {
    string user_in;
    cout << "Enter input: " << endl;
    cin >> user_in;

    unsigned int count = 0;
    for(int i = 0; i < user_in.size(); i++) {
        if(isOperator(user_in.at(i))) {
            cout << "Operator " << count+1 << " : " << user_in.at(i) << endl;
            count++;
        }
    }

    cout << "Total Operators: " << count << endl;

    return 0;
}
