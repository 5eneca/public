#include <iostream>
#include <string>
using namespace std;

int main() {
    string str;
    cout << "Enter input: " << endl;
    getline(cin, str);

    if(str[0] == '/' && str[1] == '/') 
        cout << "This is a single line comment." << endl;
    else if(str[0] == '/' && str[1] == '*' &&
            str[str.size()-2] == '*' &&
            str[str.size()-1] == '/' &&
            str.size() >= 4) cout << "This is a multi line comment" << endl;
    else cout << "This is not a comment" << endl;

    return 0;
}
