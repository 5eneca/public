 #include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <cctype>
#include <algorithm>
using namespace std;

bool isDelimiter(char ch) {
    string delimiters = " +-*/,;><=()[]{}";
    return (delimiters.find(ch) != string::npos);
}

bool isOperator(const string& ch) {
    return (ch == "+" || ch == "-" || ch == "*" ||
            ch == "/" || ch == ">" || ch == "<" ||
            ch == ">>"  || ch == "<<" || ch == ">=" ||
            ch == "<=" || ch == "!=" || ch == "==" ||
            ch == "||" || ch == "&&" || ch == "&" ||
            ch == "|" || ch == "!" || ch == "=");
}

bool validIdentifier(const string& str) {
    if (isdigit(str[0]) || isDelimiter(str[0]))
        return false;
    return true;
}

bool isKeyword(const string& str) {
    static const vector<string> keywords = {
        "if", "using", "std", "namespace", "#include",
        "#define", "cout", "cin", "endl", "else",
        "while", "do", "break", "const", "char**", "char*",
        "continue", "int", "double", "float",
        "return", "char", "case", "sizeof",
        "long", "short", "typedef", "switch", "main",
        "unsigned", "void", "static", "struct",
        "goto"};
        string tmp = str[str.size()-1] == ';' ? str.substr(0, str.size() - 1) : str;
    return (find(keywords.begin(), keywords.end(), tmp) != keywords.end());
}

bool isInteger(const string& str) {
    if (str.empty())
        return false;

    size_t start = 0;
    if (str[0] == '-') {
        start = 1;
    }

    for (size_t i = start; i < str.length(); ++i) {
        if (!isdigit(str[i]) && str[i] != ';') {
            return false;
        }
    }
    return true;
}

bool isRealNumber(const string& str) {
    if (str.empty())
        return false;
    bool hasDecimal = false;
    for (char ch : str) {
        if(ch == ';' && ch == str[str.size()-1])
            continue;
        if (!isdigit(ch) && !(ch == '-' &&
            str.find_first_not_of("-") == 0)
            && !(ch == '.' && !hasDecimal))
            return false;
        if (ch == '.')
            hasDecimal = true;
    }
    return hasDecimal;
}

void parse(const string& str) {
    stringstream ss(str);
    string token;
    while (ss >> token) {
        if (token.size() <= 2) {
            if (isOperator(token))
                cout << "'" << token << "' IS AN OPERATOR" << endl;
            else if(isDelimiter(token[0])) cout << "'" << token << "' IS AN DELIMITER" << endl;

            continue;
        }

        if (isKeyword(token))
            cout << "'" << token << "' IS A KEYWORD" << endl;
        else if (isInteger(token))
            cout << "'" << token << "' IS AN INTEGER" << endl;
        else if (isRealNumber(token))
            cout << "'" << token << "' IS A REAL NUMBER" << endl;
        else if (validIdentifier(token))
            cout << "'" << token << "' IS A VALID IDENTIFIER" << endl;
        else
            cout << "'" << token << "' IS NOT A VALID IDENTIFIER" << endl;

    }
}
int main(int argc, char** argv)
{
    ifstream file("file");
    string content((istreambuf_iterator<char>(file)),
                   istreambuf_iterator<char>());
    parse(content);
    return 0;
}
